import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import {
  keysStore, usersStore, verifyToken, getVisibility, isPublic, decryptCode, logEvent, json
} from "./_lib.mjs";
import { META, isKnownTool } from "./tools/registry-meta.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));

async function loadCode(id) {
  const buf = await readFile(join(HERE, "tools", "encrypted", id + ".enc"), "utf8");
  return decryptCode(buf); // throws if TOOL_SECRET is wrong or file tampered
}

export default async (req) => {
  const url = new URL(req.url);
  const id = url.searchParams.get("id") || "";
  const meta = META[id];
  if (!meta) return json(404, { error: "No such tool" });

  // 1. Must be a signed-in user (login gate for the whole site's tools).
  const userTok = verifyToken(req.headers.get("x-user") || "");
  if (!userTok || userTok.role !== "user") return json(401, { error: "Please sign in first", need: "login" });
  const user = await usersStore().get(userTok.uid, { type: "json" }).catch(() => null);
  if (!user || user.blocked) return json(401, { error: "Account is not active", need: "login" });

  // 2. Unless the tool is public, a valid key that includes it is also required.
  const vis = await getVisibility();
  const open = isPublic(vis, id);
  if (!open) {
    const t = verifyToken(req.headers.get("x-session") || url.searchParams.get("token") || "");
    if (!t || t.role !== "key") return json(401, { error: "Unlock with your key first", need: "key" });
    const rec = await keysStore().get(t.kh, { type: "json" }).catch(() => null);
    if (!rec || rec.revoked) return json(401, { error: "This key is no longer active", need: "key" });
    if (rec.expiresAt && Date.parse(rec.expiresAt) < Date.now()) return json(401, { error: "This key has expired", need: "key" });
    if (!Array.isArray(rec.tools) || rec.tools.indexOf(id) < 0) {
      await logEvent("tool_denied", { label: rec.label, id });
      return json(403, { error: "Your key does not include this tool" });
    }
    await logEvent("tool_opened", { label: rec.label, id, user: user.email });
  } else {
    await logEvent("tool_opened", { id, user: user.email, open: true });
  }

  let html;
  try { html = await loadCode(id); }
  catch { return json(500, { error: "This tool could not be unlocked on the server. Check TOOL_SECRET." }); }

  return json(200, { ok: true, id, name: meta.name, open, frame: !!meta.frame, height: meta.height || 0, html });
};
