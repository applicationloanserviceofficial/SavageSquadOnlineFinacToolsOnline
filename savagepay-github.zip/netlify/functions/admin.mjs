import {
  keysStore, logsStore, ownerPassword, hashKey, makeKey, signToken, verifyToken,
  timingEq, rateLimit, clientIp, logEvent, json, readJson, getVisibility, setVisibility, isPublic, getSettings, setSettings, linksStore, usersStore
} from "./_lib.mjs";
import { toolList, META, BUILTIN, builtinList, isKnownTool } from "./tools/registry-meta.mjs";

const OWNER_HOURS = 4;

async function requireOwner(body) {
  const t = verifyToken(body.token);
  if (!t || t.role !== "owner") return null;
  return t;
}

export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Use POST" });
  const body = await readJson(req);
  const action = body.action;
  const ip = clientIp(req);

  /* ---- login ---- */
  if (action === "login") {
    const limit = await rateLimit("admin:" + ip, 6, 900);
    if (!limit.ok) {
      await logEvent("owner_rate_limited", { ip });
      return json(429, { error: "Too many attempts. Try again in " + limit.retryIn + " seconds." });
    }
    if (!timingEq(String(body.password || ""), ownerPassword())) {
      await logEvent("owner_login_failed", { ip });
      return json(401, { error: "Wrong password", left: limit.left });
    }
    await logEvent("owner_login", { ip });
    return json(200, { ok: true, token: signToken({ role: "owner" }, OWNER_HOURS * 3600) });
  }

  /* ---- everything below needs a valid owner token ---- */
  const owner = await requireOwner(body);
  if (!owner) return json(401, { error: "Sign in again" });

  if (action === "tools") {
    let vis = await getVisibility();
    // Seed built-in defaults once: locked tools stay absent from the map
    // (absent = locked), public ones are written as "public".
    if (!vis.__seeded) {
      Object.keys(BUILTIN).forEach((id) => {
        if (vis[id] === undefined && !BUILTIN[id].lockedByDefault) vis[id] = "public";
      });
      vis.__seeded = true;
      await setVisibility(vis);
    }
    const server = toolList().map((t) => ({ ...t, open: isPublic(vis, t.id), builtin: false }));
    const builtin = builtinList().map((t) => ({ ...t, open: isPublic(vis, t.id), frame: false, note: "Built into the site" }));
    return json(200, { ok: true, tools: server.concat(builtin) });
  }

  // Flip one tool between "anyone can use it" and "needs a key".
  if (action === "visibility") {
    const id = String(body.id || "");
    if (!isKnownTool(id)) return json(404, { error: "No such tool" });
    const open = body.open === true || body.open === "true";
    const vis = await getVisibility();
    if (open) vis[id] = "public"; else delete vis[id];
    await setVisibility(vis);
    await logEvent(open ? "tool_made_public" : "tool_locked", { ip, id });
    return json(200, { ok: true, id, open });
  }

  if (action === "list") {
    const store = keysStore();
    const { blobs } = await store.list();
    const out = [];
    for (const b of blobs) {
      const rec = await store.get(b.key, { type: "json" }).catch(() => null);
      if (!rec) continue;
      out.push({
        kh: b.key, label: rec.label, tools: rec.tools, createdAt: rec.createdAt,
        expiresAt: rec.expiresAt, revoked: !!rec.revoked, uses: rec.uses || 0,
        maxUses: rec.maxUses || 0, lastUsedAt: rec.lastUsedAt || null, hint: rec.hint || ""
      });
    }
    out.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json(200, { ok: true, keys: out });
  }

  if (action === "create") {
    const label = String(body.label || "").trim().slice(0, 60);
    if (!label) return json(400, { error: "Give the key a label so you know who it belongs to" });

    const wanted = Array.isArray(body.tools) ? body.tools : [];
    const tools = wanted.filter((id) => isKnownTool(id));
    if (!tools.length) return json(400, { error: "Pick at least one tool" });

    const days = Math.min(3650, Math.max(0, parseInt(body.days, 10) || 0));
    const maxUses = Math.min(100000, Math.max(0, parseInt(body.maxUses, 10) || 0));

    const plain = makeKey();
    const rec = {
      label,
      tools,
      createdAt: new Date().toISOString(),
      expiresAt: days ? new Date(Date.now() + days * 86400000).toISOString() : null,
      maxUses,
      uses: 0,
      revoked: false,
      hint: plain.slice(0, 8) + "…" + plain.slice(-4)
    };
    await keysStore().setJSON(hashKey(plain), rec);
    await logEvent("key_created", { ip, label, tools, days, maxUses });

    // The plain key is returned once and never stored. If it is lost, revoke
    // this one and issue another.
    return json(200, { ok: true, key: plain, record: rec });
  }

  if (action === "revoke" || action === "restore") {
    const kh = String(body.kh || "");
    const store = keysStore();
    const rec = await store.get(kh, { type: "json" }).catch(() => null);
    if (!rec) return json(404, { error: "Key not found" });
    rec.revoked = action === "revoke";
    await store.setJSON(kh, rec);
    await logEvent(action === "revoke" ? "key_revoked" : "key_restored", { ip, label: rec.label });
    return json(200, { ok: true });
  }

  if (action === "update") {
    const kh = String(body.kh || "");
    const store = keysStore();
    const rec = await store.get(kh, { type: "json" }).catch(() => null);
    if (!rec) return json(404, { error: "Key not found" });
    if (Array.isArray(body.tools)) {
      const tools = body.tools.filter((id) => isKnownTool(id));
      if (!tools.length) return json(400, { error: "Pick at least one tool" });
      rec.tools = tools;
    }
    if (body.days !== undefined) {
      const days = Math.min(3650, Math.max(0, parseInt(body.days, 10) || 0));
      rec.expiresAt = days ? new Date(Date.now() + days * 86400000).toISOString() : null;
    }
    await store.setJSON(kh, rec);
    await logEvent("key_updated", { ip, label: rec.label });
    return json(200, { ok: true, record: rec });
  }

  if (action === "delete") {
    const kh = String(body.kh || "");
    const rec = await keysStore().get(kh, { type: "json" }).catch(() => null);
    await keysStore().delete(kh);
    await logEvent("key_deleted", { ip, label: rec ? rec.label : "unknown" });
    return json(200, { ok: true });
  }

  if (action === "logs") {
    const store = logsStore();
    const { blobs } = await store.list();
    blobs.sort((a, b) => String(b.key).localeCompare(String(a.key)));
    const recent = blobs.slice(0, 120);
    const out = [];
    for (const b of recent) {
      const rec = await store.get(b.key, { type: "json" }).catch(() => null);
      if (rec) out.push(rec);
    }
    return json(200, { ok: true, logs: out });
  }

  if (action === "settings") {
    return json(200, { ok: true, settings: await getSettings() });
  }

  if (action === "save-settings") {
    const incoming = body.settings && typeof body.settings === "object" ? body.settings : {};
    const clean = {};
    // Only known, safe fields. No secrets here — those stay in env vars.
    ["contactEmail", "telegram", "linkBase", "brandName", "tagline"].forEach((k) => {
      if (typeof incoming[k] === "string") clean[k] = incoming[k].slice(0, 200);
    });
    await setSettings(clean);
    await logEvent("settings_saved", { ip });
    return json(200, { ok: true, settings: clean });
  }

  if (action === "links") {
    const store = linksStore();
    const { blobs } = await store.list();
    const out = [];
    for (const b of blobs) {
      const rec = await store.get(b.key, { type: "json" }).catch(() => null);
      if (!rec) continue;
      out.push({ slug: b.key, url: rec.url, createdAt: rec.createdAt, expiresAt: rec.expiresAt, hits: rec.hits || 0 });
    }
    out.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json(200, { ok: true, links: out.slice(0, 200) });
  }

  if (action === "delete-link") {
    const slug = String(body.slug || "").toLowerCase();
    await linksStore().delete(slug);
    await logEvent("link_deleted", { ip, slug });
    return json(200, { ok: true });
  }

  if (action === "users") {
    const store = usersStore();
    const { blobs } = await store.list();
    const out = [];
    for (const b of blobs) {
      const rec = await store.get(b.key, { type: "json" }).catch(() => null);
      if (!rec) continue;
      out.push({ uid: b.key, email: rec.email, name: rec.name || "", createdAt: rec.createdAt, lastLogin: rec.lastLogin || null, blocked: !!rec.blocked });
    }
    out.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json(200, { ok: true, users: out.slice(0, 500) });
  }

  if (action === "block-user") {
    const uid = String(body.uid || "").toLowerCase();
    const store = usersStore();
    const rec = await store.get(uid, { type: "json" }).catch(() => null);
    if (!rec) return json(404, { error: "User not found" });
    rec.blocked = body.block === true || body.block === "true";
    await store.setJSON(uid, rec);
    await logEvent(rec.blocked ? "user_blocked" : "user_unblocked", { ip, email: rec.email });
    return json(200, { ok: true });
  }

  return json(400, { error: "Unknown action" });
};
