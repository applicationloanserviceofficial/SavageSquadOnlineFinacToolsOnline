// Public metadata only — names, notes, frame flags. NO code here.
// Safe to ship; reveals nothing secret.
export const META = {
  "bulk-upi-qr":          { name: "Bulk UPI QR generator",        note: "Paste a list of payees and get a printable sheet of QR codes.", frame: false },
  "settlement-reconciler":{ name: "Settlement reconciler",        note: "Match what you invoiced against what actually landed in the bank.", frame: false },
  "url-shortener":        { name: "URL shortener",                note: "Turn a long link into a short one, with an alias you choose.", frame: false },
  "image2url":            { name: "Image to URL converter",       note: "Upload, crop and turn an image into a shareable link.", frame: true, height: 1500 },
  "loan-crm":             { name: "Loan collection CRM generator", note: "Build and export collection records as PNG or PDF.", frame: true, height: 1600 }
};

// Built-in (in-page) tools the owner can lock. Code lives in the site.
export const BUILTIN = {
  "upi-mdr": { name: "UPI MDR calculator", lockedByDefault: true }
};

export function toolList() {
  return Object.keys(META).map((id) => ({ id, name: META[id].name, note: META[id].note || "", frame: !!META[id].frame }));
}
export function builtinList() {
  return Object.keys(BUILTIN).map((id) => ({ id, name: BUILTIN[id].name, builtin: true }));
}
export function isKnownTool(id) {
  return Object.prototype.hasOwnProperty.call(META, id) || Object.prototype.hasOwnProperty.call(BUILTIN, id);
}
