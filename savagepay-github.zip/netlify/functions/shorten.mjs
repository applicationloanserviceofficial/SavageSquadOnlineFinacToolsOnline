import { keysStore, linksStore, verifyToken, getVisibility, isPublic, getSettings, makeSlug, rateLimit, clientIp, logEvent, json, readJson } from "./_lib.mjs";

const TOOL_ID = "url-shortener";

/*
  Our own URL shortener. No third-party API.
  Links live in the savagepay-links blob store. The redirect side is served by
  the /s/:slug function (see go.mjs). Expiry is enforced at redirect time, so an
  expired link simply stops resolving — nothing to clean up, nothing to break.
*/
export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Use POST" });

  const vis = await getVisibility();
  if (!isPublic(vis, TOOL_ID)) {
    const t = verifyToken(req.headers.get("x-session") || "");
    if (!t || t.role !== "key") return json(401, { error: "Unlock with your key first" });
    const rec = await keysStore().get(t.kh, { type: "json" }).catch(() => null);
    if (!rec || rec.revoked) return json(401, { error: "This key is no longer active" });
    if (rec.expiresAt && Date.parse(rec.expiresAt) < Date.now()) return json(401, { error: "This key has expired" });
    if (!Array.isArray(rec.tools) || rec.tools.indexOf(TOOL_ID) < 0) return json(403, { error: "Your key does not include this tool" });
  }

  const ip = clientIp(req);
  const limit = await rateLimit("shorten:" + ip, 40, 3600);
  if (!limit.ok) return json(429, { error: "Too many links in one hour. Try again in " + limit.retryIn + " seconds." });

  const body = await readJson(req);
  const url = String(body.url || "").trim();
  const alias = String(body.alias || "").trim().toLowerCase();
  const days = Math.min(3650, Math.max(0, parseInt(body.days, 10) || 0));

  if (!/^https?:\/\//i.test(url)) return json(400, { error: "Start the link with http:// or https://" });
  if (url.length > 2048) return json(400, { error: "That link is too long." });
  if (alias && !/^[a-z0-9-]{3,40}$/.test(alias)) return json(400, { error: "An alias needs 3 to 40 lowercase letters, numbers or hyphens." });

  const RESERVED = ["s", "api", "owner", "admin", "assets", "static", "go", "key", "tool", "config"];
  if (alias && RESERVED.indexOf(alias) > -1) return json(400, { error: "That alias is reserved. Pick another." });

  const store = linksStore();
  let slug = alias;
  if (slug) {
    const exists = await store.get(slug, { type: "json" }).catch(() => null);
    if (exists && !(exists.expiresAt && Date.parse(exists.expiresAt) < Date.now())) {
      return json(409, { error: "That alias is already taken. Pick another." });
    }
  } else {
    // random, retry on the rare collision
    for (let i = 0; i < 6; i++) {
      slug = makeSlug(6);
      const exists = await store.get(slug, { type: "json" }).catch(() => null);
      if (!exists) break;
    }
  }

  const rec = {
    url,
    createdAt: new Date().toISOString(),
    expiresAt: days ? new Date(Date.now() + days * 86400000).toISOString() : null,
    hits: 0,
    ip
  };
  await store.setJSON(slug, rec);
  await logEvent("link_created", { ip, slug, days });

  const settings = await getSettings();
  const origin = (settings.linkBase || "").replace(/\/+$/, "") || new URL(req.url).origin;
  return json(200, { ok: true, tiny_url: origin + "/s/" + slug, slug, expiresAt: rec.expiresAt });
};
