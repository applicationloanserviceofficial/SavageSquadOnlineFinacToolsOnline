import { getVisibility, isPublic, getSettings, json } from "./_lib.mjs";
import { toolList } from "./tools/registry-meta.mjs";

// Public endpoint. Says which tools exist, which are open, and the public
// contact details the owner set. Never reveals a tool's code or any secret.
export default async () => {
  const [vis, settings] = await Promise.all([getVisibility(), getSettings()]);
  return json(200, {
    ok: true,
    tools: toolList().map((t) => ({ ...t, open: isPublic(vis, t.id) })),
    contact: {
      email: settings.contactEmail || "",
      telegram: settings.telegram || ""
    }
  });
};
