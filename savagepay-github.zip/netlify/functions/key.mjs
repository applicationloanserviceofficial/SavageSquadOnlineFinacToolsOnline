import { keysStore, hashKey, signToken, verifyToken, rateLimit, clientIp, logEvent, json, readJson } from "./_lib.mjs";

const SESSION_HOURS = 8;

export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Use POST" });

  const body = await readJson(req);
  const action = body.action || "redeem";

  if (action === "session") {
    const t = verifyToken(body.token);
    if (!t || t.role !== "key") return json(401, { error: "Session expired" });
    // Re-check the stored key so a revoked key stops working at once, even
    // though the token itself is still inside its validity window.
    const rec = await keysStore().get(t.kh, { type: "json" }).catch(() => null);
    if (!rec || rec.revoked) return json(401, { error: "This key is no longer active" });
    if (rec.expiresAt && Date.parse(rec.expiresAt) < Date.now()) return json(401, { error: "This key has expired" });
    return json(200, { ok: true, tools: rec.tools, label: rec.label, expiresAt: rec.expiresAt });
  }

  if (action !== "redeem") return json(400, { error: "Unknown action" });

  const ip = clientIp(req);
  const limit = await rateLimit("key:" + ip, 10, 600);
  if (!limit.ok) {
    await logEvent("key_rate_limited", { ip });
    return json(429, { error: "Too many attempts. Try again in " + limit.retryIn + " seconds." });
  }

  const plain = String(body.key || "").trim().toUpperCase();
  if (plain.length < 8) return json(400, { error: "Enter your key" });

  const kh = hashKey(plain);
  const rec = await keysStore().get(kh, { type: "json" }).catch(() => null);

  if (!rec || rec.revoked) {
    await logEvent("key_rejected", { ip, reason: rec ? "revoked" : "unknown" });
    return json(401, { error: "This key is not valid" });
  }
  if (rec.expiresAt && Date.parse(rec.expiresAt) < Date.now()) {
    await logEvent("key_rejected", { ip, reason: "expired", label: rec.label });
    return json(401, { error: "This key expired on " + rec.expiresAt.slice(0, 10) });
  }
  if (rec.maxUses && rec.uses >= rec.maxUses) {
    await logEvent("key_rejected", { ip, reason: "max_uses", label: rec.label });
    return json(401, { error: "This key has reached its usage limit" });
  }

  rec.uses = (rec.uses || 0) + 1;
  rec.lastUsedAt = new Date().toISOString();
  rec.lastIp = ip;
  await keysStore().setJSON(kh, rec);
  await logEvent("key_used", { ip, label: rec.label, tools: rec.tools });

  return json(200, {
    ok: true,
    token: signToken({ role: "key", kh }, SESSION_HOURS * 3600),
    tools: rec.tools,
    label: rec.label,
    expiresAt: rec.expiresAt
  });
};
