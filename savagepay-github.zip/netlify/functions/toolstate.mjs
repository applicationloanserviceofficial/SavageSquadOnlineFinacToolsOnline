import { getVisibility, isPublic, keysStore, verifyToken, logEvent, json } from "./_lib.mjs";
import { BUILTIN } from "./tools/registry-meta.mjs";

/*
  Gate for the built-in (in-page) tools. The site asks this endpoint before it
  opens a built-in tool. The code already lives in the browser, so this is an
  access check, not code delivery — a determined viewer could still read the
  page source. It stops casual use of a locked built-in tool and ties access to
  a key, which is the honest limit of any client-side tool.
*/
export default async (req) => {
  const id = new URL(req.url).searchParams.get("id") || "";
  if (!Object.prototype.hasOwnProperty.call(BUILTIN, id)) return json(404, { error: "No such tool" });

  const vis = await getVisibility();
  if (isPublic(vis, id)) return json(200, { ok: true, open: true });

  const token = req.headers.get("x-session") || "";
  const t = verifyToken(token);
  if (!t || t.role !== "key") return json(401, { error: "Unlock with your key first" });
  const rec = await keysStore().get(t.kh, { type: "json" }).catch(() => null);
  if (!rec || rec.revoked) return json(401, { error: "This key is no longer active" });
  if (rec.expiresAt && Date.parse(rec.expiresAt) < Date.now()) return json(401, { error: "This key has expired" });
  if (!Array.isArray(rec.tools) || rec.tools.indexOf(id) < 0) {
    await logEvent("builtin_denied", { label: rec.label, id });
    return json(403, { error: "Your key does not include this tool" });
  }
  await logEvent("builtin_opened", { label: rec.label, id });
  return json(200, { ok: true, open: false });
};
