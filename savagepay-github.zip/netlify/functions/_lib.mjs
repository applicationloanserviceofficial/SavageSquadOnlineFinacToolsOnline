import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

/* ---------- stores ---------- */
export const keysStore   = () => getStore({ name: "savagepay-keys",   consistency: "strong" });
export const logsStore   = () => getStore({ name: "savagepay-logs",   consistency: "strong" });
export const rateStore   = () => getStore({ name: "savagepay-rate",   consistency: "strong" });
export const configStore = () => getStore({ name: "savagepay-config", consistency: "strong" });
export const linksStore  = () => getStore({ name: "savagepay-links",  consistency: "strong" });
export const usersStore  = () => getStore({ name: "savagepay-users",  consistency: "strong" });

/* ---------- secrets ---------- */
export function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 24) throw new Error("SESSION_SECRET is missing or too short");
  return s;
}
export function ownerPassword() {
  const p = process.env.OWNER_PASSWORD;
  if (!p || p.length < 10) throw new Error("OWNER_PASSWORD is missing or too short");
  return p;
}

/* ---------- settings stored in the panel (not secrets) ----------
   Small key/value bag the owner edits from the Settings tab: contact details,
   link domain, and similar. Secrets still live in environment variables. */
export async function getSettings() {
  try {
    const v = await configStore().get("settings", { type: "json" });
    return v && typeof v === "object" ? v : {};
  } catch { return {}; }
}
export async function setSettings(map) {
  await configStore().setJSON("settings", map);
}

/* ---------- password hashing (scrypt, per-user salt) ---------- */
export function hashPassword(plain) {
  const salt = crypto.randomBytes(16);
  const dk = crypto.scryptSync(String(plain), salt, 32, { N: 16384, r: 8, p: 1 });
  return "scrypt$" + salt.toString("hex") + "$" + dk.toString("hex");
}
export function verifyPassword(plain, stored) {
  try {
    const [scheme, saltHex, hashHex] = String(stored).split("$");
    if (scheme !== "scrypt") return false;
    const salt = Buffer.from(saltHex, "hex");
    const want = Buffer.from(hashHex, "hex");
    const got = crypto.scryptSync(String(plain), salt, want.length, { N: 16384, r: 8, p: 1 });
    return crypto.timingSafeEqual(got, want);
  } catch { return false; }
}

/* ---------- AES-256-GCM for protected tool code ----------
   The tool source is stored encrypted. The key lives only in TOOL_SECRET
   (an environment variable), never in any blob. A stolen blob store yields
   only ciphertext. */
function toolKey() {
  const s = process.env.TOOL_SECRET;
  if (!s || s.length < 32) throw new Error("TOOL_SECRET is missing or too short");
  return crypto.createHash("sha256").update(s).digest(); // 32 bytes
}
export function encryptCode(plainText) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", toolKey(), iv);
  const enc = Buffer.concat([c.update(Buffer.from(plainText, "utf8")), c.final()]);
  const tag = c.getAuthTag();
  return "v1." + iv.toString("base64") + "." + tag.toString("base64") + "." + enc.toString("base64");
}
export function decryptCode(blob) {
  const [v, ivB, tagB, dataB] = String(blob).split(".");
  if (v !== "v1") throw new Error("bad ciphertext");
  const d = crypto.createDecipheriv("aes-256-gcm", toolKey(), Buffer.from(ivB, "base64"));
  d.setAuthTag(Buffer.from(tagB, "base64"));
  return Buffer.concat([d.update(Buffer.from(dataB, "base64")), d.final()]).toString("utf8");
}

/* ---------- hashing ---------- */
export function hashKey(plain) {
  return crypto.createHmac("sha256", secret()).update("key:" + plain).digest("hex");
}
export function timingEq(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  if (x.length !== y.length) return false;
  return crypto.timingSafeEqual(x, y);
}

/* ---------- signed tokens ---------- */
function b64url(buf) {
  return Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function unb64url(str) {
  return Buffer.from(String(str).replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
}
export function signToken(payload, ttlSeconds) {
  const body = { ...payload, exp: Math.floor(Date.now() / 1000) + ttlSeconds };
  const data = b64url(JSON.stringify(body));
  const sig = b64url(crypto.createHmac("sha256", secret()).update(data).digest());
  return data + "." + sig;
}
export function verifyToken(token) {
  if (typeof token !== "string" || token.indexOf(".") < 0) return null;
  const [data, sig] = token.split(".");
  const want = b64url(crypto.createHmac("sha256", secret()).update(data).digest());
  if (!timingEq(sig, want)) return null;
  let body;
  try { body = JSON.parse(unb64url(data)); } catch { return null; }
  if (!body.exp || body.exp < Math.floor(Date.now() / 1000)) return null;
  return body;
}

/* ---------- key generation ---------- */
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
export function makeKey() {
  const bytes = crypto.randomBytes(16);
  let out = "";
  for (let i = 0; i < 16; i++) {
    if (i > 0 && i % 4 === 0) out += "-";
    out += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return "SVG-" + out;
}
export function makeSlug(n) {
  const bytes = crypto.randomBytes(n || 6);
  let out = "";
  for (let i = 0; i < (n || 6); i++) out += ALPHABET[bytes[i] % ALPHABET.length];
  return out.toLowerCase();
}

/* ---------- visibility: which tools are open to everyone ---------- */
export async function getVisibility() {
  try {
    const v = await configStore().get("visibility", { type: "json" });
    return v && typeof v === "object" ? v : {};
  } catch { return {}; }
}
export async function setVisibility(map) {
  await configStore().setJSON("visibility", map);
}
export function isPublic(map, id) {
  return map[id] === "public";
}

/* ---------- email validation ---------- */
export function validEmail(e) {
  return typeof e === "string" && /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(e) && e.length <= 254;
}
export function emailKey(e) {
  // stable, lowercased id for the blob key
  return String(e).trim().toLowerCase();
}

/* ---------- rate limiting ---------- */
export async function rateLimit(bucket, max, windowSeconds) {
  const store = rateStore();
  const now = Date.now();
  let rec = null;
  try { rec = await store.get(bucket, { type: "json" }); } catch { rec = null; }
  if (!rec || rec.resetAt < now) rec = { n: 0, resetAt: now + windowSeconds * 1000 };
  rec.n += 1;
  await store.setJSON(bucket, rec);
  return { ok: rec.n <= max, left: Math.max(0, max - rec.n), retryIn: Math.ceil((rec.resetAt - now) / 1000) };
}
export function clientIp(req) {
  const h = req.headers;
  return (h.get("x-nf-client-connection-ip") || h.get("x-forwarded-for") || "unknown").split(",")[0].trim();
}

/* ---------- audit log ---------- */
export async function logEvent(event, detail) {
  try {
    const id = Date.now() + "-" + crypto.randomBytes(4).toString("hex");
    await logsStore().setJSON(id, { at: new Date().toISOString(), event, ...detail });
  } catch { /* logging must never break the request */ }
}

/* ---------- responses ---------- */
export function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" }
  });
}
export async function readJson(req) {
  try { return await req.json(); } catch { return {}; }
}
