import {
  usersStore, hashPassword, verifyPassword, signToken, verifyToken,
  validEmail, emailKey, rateLimit, clientIp, logEvent, json, readJson
} from "./_lib.mjs";

const SESSION_DAYS = 30;

export default async (req) => {
  if (req.method !== "POST") return json(405, { error: "Use POST" });
  const body = await readJson(req);
  const action = body.action || "login";
  const ip = clientIp(req);

  /* ---- confirm an existing session ---- */
  if (action === "session") {
    const t = verifyToken(body.token);
    if (!t || t.role !== "user") return json(401, { error: "Session expired" });
    const rec = await usersStore().get(t.uid, { type: "json" }).catch(() => null);
    if (!rec || rec.blocked) return json(401, { error: "Account is not active" });
    return json(200, { ok: true, email: rec.email, name: rec.name || "" });
  }

  /* ---- sign up ---- */
  if (action === "signup") {
    const limit = await rateLimit("signup:" + ip, 8, 3600);
    if (!limit.ok) return json(429, { error: "Too many sign-ups from here. Try again in " + limit.retryIn + " seconds." });

    const email = String(body.email || "").trim();
    const pw = String(body.password || "");
    const name = String(body.name || "").trim().slice(0, 60);

    if (!validEmail(email)) return json(400, { error: "Enter a valid email address" });
    if (pw.length < 8) return json(400, { error: "Use a password of at least 8 characters" });
    if (pw.length > 200) return json(400, { error: "That password is too long" });

    const uid = emailKey(email);
    const store = usersStore();
    const exists = await store.get(uid, { type: "json" }).catch(() => null);
    if (exists) return json(409, { error: "An account with this email already exists. Try signing in." });

    const rec = {
      email: email.trim(),
      name,
      pass: hashPassword(pw),
      createdAt: new Date().toISOString(),
      provider: "password",
      blocked: false
    };
    await store.setJSON(uid, rec);
    await logEvent("user_signup", { ip, email: rec.email });
    return json(200, { ok: true, token: signToken({ role: "user", uid }, SESSION_DAYS * 86400), email: rec.email, name: rec.name });
  }

  /* ---- sign in ---- */
  if (action === "login") {
    const limit = await rateLimit("login:" + ip, 10, 900);
    if (!limit.ok) return json(429, { error: "Too many attempts. Try again in " + limit.retryIn + " seconds." });

    const email = String(body.email || "").trim();
    const pw = String(body.password || "");
    if (!validEmail(email)) return json(400, { error: "Enter a valid email address" });

    const uid = emailKey(email);
    const store = usersStore();
    const rec = await store.get(uid, { type: "json" }).catch(() => null);

    // Per-account lockout after repeated failures, on top of the per-IP limit.
    if (rec && rec.lockUntil && Date.parse(rec.lockUntil) > Date.now()) {
      return json(429, { error: "This account is locked for a few minutes after several wrong passwords." });
    }

    // Always run a verify to keep the timing similar whether or not the user exists.
    const ok = rec ? verifyPassword(pw, rec.pass) : verifyPassword(pw, "scrypt$00$00");
    if (!rec || !ok) {
      if (rec) {
        rec.fails = (rec.fails || 0) + 1;
        if (rec.fails >= 6) { rec.lockUntil = new Date(Date.now() + 10 * 60000).toISOString(); rec.fails = 0; }
        await store.setJSON(uid, rec);
      }
      await logEvent("user_login_failed", { ip, email });
      return json(401, { error: "Wrong email or password" });
    }
    if (rec.blocked) return json(403, { error: "This account has been blocked" });

    rec.fails = 0; rec.lockUntil = null; rec.lastLogin = new Date().toISOString();
    await store.setJSON(uid, rec);
    await logEvent("user_login", { ip, email: rec.email });
    return json(200, { ok: true, token: signToken({ role: "user", uid }, SESSION_DAYS * 86400), email: rec.email, name: rec.name || "" });
  }

  return json(400, { error: "Unknown action" });
};
