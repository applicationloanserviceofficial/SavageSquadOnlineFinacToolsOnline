import { linksStore, logEvent } from "./_lib.mjs";

// Redirect handler for /s/:slug. Wired up in netlify.toml.
export default async (req) => {
  const slug = (new URL(req.url).pathname.split("/").filter(Boolean).pop() || "").toLowerCase();
  if (!slug) return new Response("Not found", { status: 404 });

  const rec = await linksStore().get(slug, { type: "json" }).catch(() => null);
  const gone = () => new Response(
    "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>" +
    "<title>Link unavailable</title><body style='font-family:system-ui;background:#f2f6f3;color:#0f2a22;display:grid;place-items:center;height:100vh;margin:0;text-align:center'>" +
    "<div><h1 style='font-size:24px'>This link is no longer available</h1><p style='color:#5a6f66'>It may have expired or been removed.</p><a href='/' style='color:#0b7a5c;font-weight:700'>Go to SavagePay</a></div>",
    { status: 410, headers: { "content-type": "text/html; charset=utf-8" } });

  if (!rec) return gone();
  if (rec.expiresAt && Date.parse(rec.expiresAt) < Date.now()) return gone();

  rec.hits = (rec.hits || 0) + 1;
  rec.lastAt = new Date().toISOString();
  linksStore().setJSON(slug, rec).catch(() => {});
  logEvent("link_opened", { slug, hits: rec.hits }).catch(() => {});

  return new Response(null, { status: 302, headers: { location: rec.url, "cache-control": "no-store" } });
};
