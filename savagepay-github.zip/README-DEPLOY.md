# SavagePay — GitHub দিয়ে ডিপ্লয় (সম্পূর্ণ গাইড)

এই পদ্ধতিতে সব ফাংশন (লগইন, key, এনক্রিপশন, owner panel) ঠিকভাবে চলবে।
জিপ-ড্রপে যে 502 সমস্যা হচ্ছিল, এখানে হবে না — কারণ GitHub দিয়ে ডিপ্লয় করলে
Netlify নিজে দরকারি প্যাকেজ ইনস্টল করে।

---

## কেন GitHub দরকার

Netlify Drop (জিপ টেনে ছাড়া) npm প্যাকেজ ইনস্টল করে না। আপনার ফাংশনগুলোর
`@netlify/blobs` প্যাকেজ লাগে — সেটা না থাকায় ফাংশন ক্র্যাশ করে, 502 আসে।
GitHub-এর সাথে যুক্ত করলে Netlify প্রতিবার নিজে প্যাকেজ ইনস্টল করে, তাই সব চলে।

---

## ধাপ ১ — GitHub অ্যাকাউন্ট ও রিপো

1. [github.com](https://github.com) এ একটা ফ্রি অ্যাকাউন্ট খুলুন (না থাকলে)
2. লগইন করে ডানদিকে উপরে **+** → **New repository**
3. Repository name: `savagepay` (বা যা চান)
4. **Private** বেছে নিন — এটাই সবচেয়ে জরুরি। তাহলে কোড কেউ দেখতে পাবে না।
5. **Create repository**

## ধাপ ২ — ফাইল আপলোড

রিপো তৈরি হলে একটা খালি পেজ আসবে। সেখানে:

1. **uploading an existing file** লিংকে ক্লিক করুন (অথবা Add file → Upload files)
2. এই ফোল্ডারের **সব ফাইল আর `netlify` ফোল্ডারটা** টেনে ছাড়ুন (বা Choose your files দিয়ে বাছুন)
3. নিচে **Commit changes** চাপুন

ফোনে করলে: GitHub মোবাইল সাইট বা অ্যাপ দিয়ে Add file → Upload files।
একসাথে ফোল্ডার তুলতে না পারলে, কম্পিউটার থেকে করাই সহজ।

> মনে রাখবেন: `.gitignore` ফাইলটা আছে বলে আসল টুল-কোড (registry.mjs, app-*.mjs)
> রিপোতে যাবেই না, শুধু এনক্রিপ্টেড `.enc` ফাইল যাবে। তাই GitHub প্রাইভেট না হলেও
> আপনার টুলের কৌশল সুরক্ষিত।

## ধাপ ৩ — Netlify-তে যুক্ত করা

1. Netlify খুলুন → **Add new site** / **Import an existing project**
2. **Deploy with GitHub** / **Import from Git** বেছে নিন
3. প্রথমবার GitHub-এর সাথে যুক্ত করতে বলবে — **Authorize** দিন
4. আপনার `savagepay` রিপো বেছে নিন
5. Build settings নিজে থেকেই ঠিক থাকবে (netlify.toml থেকে পড়ে নেবে):
   - Build command: **খালি রাখুন** (কিছু লিখবেন না)
   - Publish directory: `.`
   - Functions directory: `netlify/functions`
6. **Deploy site**

প্রথম ডিপ্লয়ে ১-২ মিনিট লাগবে — Netlify প্যাকেজ ইনস্টল করে, ফাংশন বানায়।

## ধাপ ৪ — Environment Variables (অবশ্যই)

Site configuration → Environment variables → তিনটে যোগ করুন:

| Key | Value |
|---|---|
| `OWNER_PASSWORD` | আপনার পাসওয়ার্ড, ১২+ অক্ষর, কঠিন |
| `SESSION_SECRET` | ৩২+ অক্ষর এলোমেলো |
| `TOOL_SECRET` | `build-time-demo-secret-change-me-32xx` |

`TOOL_SECRET`-এ হুবহু ওই ডেমো মানটাই দেবেন, কারণ `.enc` ফাইলগুলো সেটা দিয়ে
এনক্রিপ্ট করা। (নিজের সিক্রেট চাইলে আলাদা ব্যবস্থা লাগবে — নিচে ধাপ ৭ দেখুন।)

যোগ করার পর → **Deploys** → **Trigger deploy** → **Deploy site**

## ধাপ ৫ — পরীক্ষা

1. সাইট খুলুন (Netlify-র দেওয়া ঠিকানা)
2. কোনো টুলে ঢুকে দেখুন — "Sign in" আসবে
3. **New here? Sign up** → নাম, ইমেইল, পাসওয়ার্ড দিয়ে অ্যাকাউন্ট বানান
4. এবার সাইন ইন হবে, আর পাবলিক টুল চলবে
5. `আপনার-সাইট/owner.html` খুলে `OWNER_PASSWORD` দিয়ে ঢুকুন
6. **Access** ট্যাবে কোন টুল lock, কোনটা public — ঠিক করুন

502 আসবে না। এলে বুঝবেন env variable বসাননি বা Trigger deploy করেননি।

## ধাপ ৬ — ডোমেইন

Netlify → Domain management → Add domain → `savage-pay-official.top`।
DNS আগেই সেট করা থাকলে এমনিতেই যুক্ত হবে।

---

## আপনার লক/পাবলিক চাওয়া অনুযায়ী

- **নতুন ডিফল্ট: সব সার্ভার-টুল lock।** কোনো টুল public নয় যতক্ষণ না আপনি owner
  panel → Access ট্যাব থেকে নিজে public করেন। তাই ভুলেও কিছু ফাঁস হবে না।
- আগের স্ক্রিনশটে টুল "খোলা" দেখাচ্ছিল কারণ ফাংশনই চলছিল না (502)। ফাংশন চালু হলে
  lock ঠিকভাবে কাজ করবে।
- public করতে চাইলে এক ক্লিক, আবার lock করতে চাইলেও এক ক্লিক — সব owner panel থেকে।

## owner panel কেউ যেন না পায়

- `owner.html` সার্চ ইঞ্জিন থেকে লুকানো (robots + noindex)
- ঢুকতে `OWNER_PASSWORD` লাগে, যেটা শুধু আপনার Netlify-তে আছে, কোডে নেই
- ৬ বার ভুল পাসওয়ার্ডে ১৫ মিনিট ব্লক
- ঠিকানাটা কাউকে দেবেন না — শুধু আপনি জানবেন

বাড়তি সুরক্ষা চাইলে Netlify-র **Password protection** (Site configuration →
Access control) দিয়ে পুরো সাইট বা নির্দিষ্ট পথ পাসওয়ার্ড-লক করা যায়, তবে এটা
paid ফিচার। সাধারণত OWNER_PASSWORD-ই যথেষ্ট।

---

## ধাপ ৭ — (ঐচ্ছিক) নিজের TOOL_SECRET দিয়ে এনক্রিপ্ট

ডেমো সিক্রেটের বদলে নিজের সিক্রেট চাইলে, কম্পিউটারে Node দিয়ে:

```
# আসল টুল-কোড লাগবে — savagepay-project.zip থেকে নিন
cd netlify/functions/tools
TOOL_SECRET=আপনার-নিজের-সিক্রেট node encrypt-tools.cjs
```

এতে নতুন `.enc` ফাইল হবে। সেগুলো রিপোতে push করুন, আর Netlify-তে `TOOL_SECRET`-এ
একই সিক্রেট দিন। দুই জায়গায় এক সিক্রেট না হলে টুল খুলবে না।

---

## সমস্যা হলে

- **502 / "Request failed"** → env variable বসাননি, বা Trigger deploy করেননি।
  তিনটে env দিয়ে Clear cache and deploy করুন।
- **Functions মেনু খালি** → GitHub deploy-এ এটা হওয়ার কথা নয়। netlify.toml ঠিক
  জায়গায় আছে কি না দেখুন (রিপোর একদম উপরে)।
- **টুল খোলে না, "could not be unlocked"** → TOOL_SECRET ভুল। ডেমো মানটা হুবহু দিন।
- **সাইন আপ হয় না** → ফাংশন চলছে না, উপরের 502 ঠিক করুন।
